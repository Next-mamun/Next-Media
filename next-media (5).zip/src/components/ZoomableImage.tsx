import React, { useState } from 'react';
import { X, ZoomIn } from 'lucide-react';

interface ZoomableImageProps {
  src: string;
  alt?: string;
  className?: string;
  referrerPolicy?: React.HTMLAttributeReferrerPolicy;
}

const ZoomableImage: React.FC<ZoomableImageProps> = ({ src, alt, className, referrerPolicy }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <div className="relative group cursor-zoom-in overflow-hidden w-full h-full" onClick={() => setIsOpen(true)}>
        <img src={src} alt={alt} className={className} referrerPolicy={referrerPolicy} />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
           <div className="bg-white/20 backdrop-blur-md p-2 rounded-full text-white shadow-lg">
             <ZoomIn size={24} />
           </div>
        </div>
      </div>

      {isOpen && (
        <div className="fixed inset-0 z-[9999] bg-black/95 flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setIsOpen(false)}>
          <button 
            className="absolute top-4 right-4 text-white p-2 hover:bg-white/10 rounded-full transition-colors z-50"
            onClick={(e) => { e.stopPropagation(); setIsOpen(false); }}
          >
            <X size={32} />
          </button>
          <img 
            src={src} 
            alt={alt} 
            className="max-w-full max-h-full object-contain shadow-2xl animate-in zoom-in-95 duration-300" 
            referrerPolicy={referrerPolicy}
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </>
  );
};

export default ZoomableImage;
