
import React from 'react';
import { Link } from 'react-router-dom';
import { Users, Bookmark, Flag, Calendar, Settings, ChevronDown, UserCircle, TrendingUp, Hash } from 'lucide-react';
import { useAuth } from '@/App';
import { VerifiedBadge } from './VerifiedBadge';

const SidebarItem: React.FC<{ icon: React.ReactNode, label: string | React.ReactNode, to: string }> = ({ icon, label, to }) => (
  <Link to={to} className="flex items-center gap-3 p-3 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg transition-colors">
    <div className="text-[#1877F2]">{icon}</div>
    <span className="font-medium text-sm text-gray-700 dark:text-gray-300">{label}</span>
  </Link>
);

const Sidebar: React.FC = () => {
  const { currentUser } = useAuth();

  const trendingTopics = [
    { tag: '#NextMediaLaunch', posts: '125K' },
    { tag: '#AIArt', posts: '84K' },
    { tag: '#TechNews2024', posts: '56K' },
    { tag: '#ReactJS', posts: '42K' },
    { tag: '#WebDevelopment', posts: '28K' },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-[360px] h-[calc(100vh-56px)] sticky top-14 p-2 overflow-y-auto scrollbar-hide">
      <SidebarItem 
        icon={<img src={currentUser?.avatar_url} className="w-8 h-8 rounded-full object-cover" alt="me" />} 
        label={
          <div className="flex items-center gap-1">
            {currentUser?.display_name || 'Profile'}
            {currentUser?.is_verified && <VerifiedBadge />}
          </div>
        } 
        to={`/profile/${currentUser?.username}`}
      />
      <SidebarItem icon={<Users size={24} />} label="Friends" to="/friends" />
      <SidebarItem icon={<UserCircle size={24} />} label="Groups" to="/" />
      <SidebarItem icon={<Flag size={24} />} label="Pages" to="/" />
      <SidebarItem icon={<Bookmark size={24} />} label="Saved" to="/" />
      <SidebarItem icon={<Calendar size={24} />} label="Events" to="/" />
      <SidebarItem icon={<Settings size={24} />} label="Settings" to="/settings" />
      
      <button className="flex items-center gap-3 p-3 hover:bg-gray-200 rounded-lg transition-colors mb-4">
        <div className="bg-gray-200 p-1.5 rounded-full"><ChevronDown size={18} /></div>
        <span className="font-medium text-sm">See more</span>
      </button>

      <div className="border-t border-gray-300 mx-2 my-2"></div>

      <div className="px-3 py-2">
        <h3 className="text-gray-500 font-bold text-[15px] mb-3 flex items-center gap-2">
          <TrendingUp size={18} /> Trending Topics
        </h3>
        <div className="flex flex-col gap-3">
          {trendingTopics.map((topic, index) => (
            <div key={index} className="flex items-start gap-2 cursor-pointer hover:bg-gray-200 p-2 rounded-lg transition-colors">
              <div className="bg-[#e7f3ff] text-[#1877F2] p-1.5 rounded-md mt-0.5">
                <Hash size={16} />
              </div>
              <div>
                <p className="font-bold text-sm text-gray-800">{topic.tag}</p>
                <p className="text-xs text-gray-500">{topic.posts} posts</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-auto p-4 text-[13px] text-gray-500">
        <p>Privacy · Terms · Advertising · Cookies · Meta © 2024</p>
      </div>
    </aside>
  );
};

export default Sidebar;
