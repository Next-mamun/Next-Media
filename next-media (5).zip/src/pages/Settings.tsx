import React, { useState, useMemo, useEffect } from 'react';
import { 
  User, Lock, Bell, Shield, Globe, HelpCircle, Search, ChevronRight, 
  Monitor, Database, Briefcase, Smartphone, Key, UserX, EyeOff, 
  MessageSquare, Volume2, Moon, Sun, Type, HardDrive, Download, 
  BarChart3, DollarSign, AlertTriangle, FileText, RefreshCw, CheckCircle, Upload
} from 'lucide-react';
import { useAuth, useTheme } from '@/App';

import { supabase } from '../lib/supabase';
import { VerifiedBadge } from '@/components/VerifiedBadge';

// Reusable Toggle Component
const Toggle: React.FC<{ checked: boolean, onChange: () => void }> = ({ checked, onChange }) => (
  <button 
    onClick={onChange} 
    className={`w-12 h-6 rounded-full transition-colors relative flex-shrink-0 focus:outline-none focus:ring-2 focus:ring-blue-300 ${checked ? 'bg-[#1A2933]' : 'bg-gray-300'}`}
  >
    <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform shadow-sm ${checked ? 'left-[26px]' : 'left-0.5'}`} />
  </button>
);

// Reusable Section Component
const Section: React.FC<{ title: string, children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-8">
    <h3 className="text-lg font-black text-gray-900 dark:text-white mb-4">{title}</h3>
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl overflow-hidden shadow-sm transition-colors">
      {children}
    </div>
  </div>
);

// Reusable Row Component
const Row: React.FC<{ icon?: React.ReactNode, title: string, description?: string, action: React.ReactNode, border?: boolean }> = ({ icon, title, description, action, border = true }) => (
  <div className={`flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors ${border ? 'border-b border-gray-100 dark:border-gray-700' : ''}`}>
    <div className="flex items-center gap-4 pr-4">
      {icon && <div className="text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 p-2 rounded-lg">{icon}</div>}
      <div>
        <p className="font-bold text-gray-900 dark:text-gray-100 text-[15px]">{title}</p>
        {description && <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5 leading-snug">{description}</p>}
      </div>
    </div>
    <div className="flex-shrink-0">
      {action}
    </div>
  </div>
);

const Settings: React.FC = () => {
  const { currentUser } = useAuth();
  const { darkMode, toggleDarkMode } = useTheme();
  const [activeTab, setActiveTab] = useState('account');
  const [searchQuery, setSearchQuery] = useState('');
  const [verificationFile, setVerificationFile] = useState<File | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    if (currentUser) {
      fetchProfile();
    }
  }, [currentUser]);

  const fetchProfile = async () => {
    const { data } = await supabase.from('profiles').select('*').eq('id', currentUser?.id).single();
    if (data) setProfile(data);
  };

  // Mock States for Toggles
  const [toggles, setToggles] = useState<Record<string, boolean>>({
    '2fa': false,
    'saved_login': true,
    'private_account': false,
    'active_status': true,
    'push_likes': true,
    'push_comments': true,
    'quiet_mode': false,
    'in_app_sounds': true,
    'data_saver': false,
    'high_quality': true,
    'auto_play': true,
  });

  const handleToggle = (key: string) => setToggles(prev => ({ ...prev, [key]: !prev[key] }));

  const handleVerificationUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setVerificationFile(e.target.files[0]);
    }
  };

  const submitVerification = async () => {
    if (!verificationFile || !currentUser) return;
    setIsVerifying(true);
    
    try {
      // In a real app, we'd upload to Supabase Storage. For now, we'll use base64
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(verificationFile);
      });

      const { error } = await supabase.from('profiles').update({
        verification_document_url: base64,
        verification_status: 'pending'
      }).eq('id', currentUser.id);

      if (error) throw error;

      alert("Verification request sent! Admin will review your ID.");
      setVerificationFile(null);
      fetchProfile();
    } catch (error: any) {
      alert("Failed to submit: " + error.message);
    } finally {
      setIsVerifying(false);
    }
  };

  const settingsTabs = [
    { id: 'account', icon: <User size={20} />, label: 'Account Center', keywords: ['password', 'security', '2fa', 'email', 'phone', 'deactivate', 'delete', 'legacy', 'login'] },
    { id: 'verification', icon: <CheckCircle size={20} />, label: 'Verification', keywords: ['blue badge', 'verified', 'id', 'badge'] },
    { id: 'privacy', icon: <Shield size={20} />, label: 'Privacy Controls', keywords: ['public', 'private', 'block', 'mute', 'status', 'comments', 'tags', 'messages', 'restricted'] },
    { id: 'notifications', icon: <Bell size={20} />, label: 'Notifications', keywords: ['push', 'quiet', 'sounds', 'email', 'sms', 'alerts', 'disturb'] },
    { id: 'display', icon: <Monitor size={20} />, label: 'Content & Display', keywords: ['dark mode', 'light mode', 'font', 'size', 'sensitive', 'quality', 'data saver', 'muted words'] },

    { id: 'help', icon: <HelpCircle size={20} />, label: 'Help & Support', keywords: ['report', 'support', 'terms', 'privacy policy', 'update', 'version', 'bug'] },
  ];

  const filteredTabs = useMemo(() => {
    if (!searchQuery.trim()) return settingsTabs;
    const query = searchQuery.toLowerCase();
    return settingsTabs.filter(tab => 
      tab.label.toLowerCase().includes(query) || 
      tab.keywords.some(kw => kw.includes(query))
    );
  }, [searchQuery]);

  useEffect(() => {
    if (searchQuery && filteredTabs.length > 0 && !filteredTabs.find(t => t.id === activeTab)) {
      setActiveTab(filteredTabs[0].id);
    }
  }, [searchQuery, filteredTabs, activeTab]);

  return (
    <div className="max-w-[1200px] mx-auto bg-white dark:bg-gray-900 rounded-2xl shadow-sm flex flex-col md:flex-row h-[calc(100vh-80px)] overflow-hidden border border-gray-200 dark:border-gray-800 transition-colors">
      {/* Sidebar */}
      <div className="w-80 border-r border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 flex flex-col">
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900">
          <h1 className="text-2xl font-black mb-4 text-gray-900 dark:text-white">Settings</h1>
          <div className="bg-[#f0f2f5] dark:bg-gray-800 rounded-xl flex items-center px-3 py-2 border border-transparent focus-within:border-blue-300 transition-all">
            <Search size={18} className="text-gray-400" />
            <input 
              type="text" 
              placeholder="Search settings..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent border-none outline-none ml-2 text-sm w-full font-bold text-gray-700 dark:text-gray-200 placeholder-gray-400"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-1 scrollbar-hide">
          {filteredTabs.length === 0 ? (
            <div className="text-center p-4 text-gray-500 font-bold text-sm">No settings found for "{searchQuery}"</div>
          ) : (
            filteredTabs.map(tab => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center justify-between p-3 rounded-xl font-bold transition-all ${activeTab === tab.id ? 'bg-[#e7f3ff] dark:bg-[#1A2933] text-[#1A2933] dark:text-blue-400 shadow-sm' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-200/50 dark:hover:bg-gray-800'}`}
              >
                <div className="flex items-center gap-3">
                  {tab.icon}
                  {tab.label}
                </div>
                {activeTab === tab.id && <ChevronRight size={16} />}
              </button>
            ))
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto bg-white dark:bg-gray-900 relative scrollbar-hide">
        <div className="max-w-3xl mx-auto p-4 md:p-8 pb-20">
          
          {/* 1. Account Center */}
          {activeTab === 'account' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h2 className="text-3xl font-black mb-2 text-gray-900 dark:text-white">Account Center</h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium mb-8">Manage your identity, security, and account ownership.</p>
              
              <Section title="Personal Information">
                <Row icon={<User size={20}/>} title="Display Name" description={currentUser?.display_name} action={<button className="text-[#1A2933] dark:text-blue-400 font-bold hover:underline">Edit</button>} />
                <Row icon={<Smartphone size={20}/>} title="Contact Info" description="Manage your emails and phone numbers" action={<button className="text-[#1A2933] dark:text-blue-400 font-bold hover:underline">Manage</button>} border={false} />
              </Section>

              <Section title="Password & Security">
                <Row icon={<Lock size={20}/>} title="Change Password" description="Update your password regularly" action={<button className="bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-white px-4 py-1.5 rounded-lg font-bold transition-colors">Update</button>} />
                <Row icon={<Key size={20}/>} title="Two-Factor Authentication (2FA)" description="Add an extra layer of security" action={<Toggle checked={toggles['2fa']} onChange={() => handleToggle('2fa')} />} />
                <Row icon={<Monitor size={20}/>} title="Login Activity" description="See devices currently logged in" action={<button className="bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-white px-4 py-1.5 rounded-lg font-bold transition-colors">View</button>} />
                <Row icon={<Shield size={20}/>} title="Saved Login" description="Remember password on this device" action={<Toggle checked={toggles['saved_login']} onChange={() => handleToggle('saved_login')} />} border={false} />
              </Section>

              <Section title="Account Ownership">
                <Row icon={<UserX size={20}/>} title="Deactivation or Deletion" description="Temporarily hide or permanently delete your account" action={<button className="text-red-500 font-bold hover:underline">Manage</button>} />
                <Row icon={<FileText size={20}/>} title="Legacy Contact" description="Choose who manages your account if you pass away" action={<button className="text-[#1A2933] dark:text-blue-400 font-bold hover:underline">Select</button>} border={false} />
              </Section>
            </div>
          )}

          {/* Verification */}
          {activeTab === 'verification' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h2 className="text-3xl font-black mb-2 text-gray-900 dark:text-white">Request Verification</h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium mb-8">Apply for a blue badge to confirm your authenticity.</p>

              {profile?.verification_status === 'pending' ? (
                <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800 rounded-2xl p-8 text-center">
                  <RefreshCw size={48} className="mx-auto text-orange-500 animate-spin mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Request Pending</h3>
                  <p className="text-gray-600 dark:text-gray-300">Your verification request is currently being reviewed by our team. This usually takes 24-48 hours.</p>
                </div>
              ) : profile?.is_verified ? (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-100 dark:border-green-800 rounded-2xl p-8 text-center">
                  <VerifiedBadge size={48} className="mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Account Verified</h3>
                  <p className="text-gray-600 dark:text-gray-300">Your account is officially verified. The blue badge is now visible next to your name.</p>
                </div>
              ) : (
                <>
                  <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-2xl p-6 mb-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 dark:bg-blue-800 p-3 rounded-full">
                        <CheckCircle className="text-[#1A2933] dark:text-blue-400" size={32} />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">What is a verified badge?</h3>
                        <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                          A verified badge is a check that appears next to a Next Media account's name to indicate that the account is the authentic presence of a notable public figure, celebrity, or global brand.
                        </p>
                      </div>
                    </div>
                  </div>

                  <Section title="Step 1: Confirm Authenticity">
                    <div className="p-6">
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Upload an official government-issued photo ID (e.g. Driver's License, Passport, or National ID Card) to verify your identity.</p>
                      
                      <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 flex flex-col items-center justify-center text-center hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer relative">
                        <input type="file" onChange={handleVerificationUpload} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*,.pdf" />
                        {verificationFile ? (
                          <div className="flex flex-col items-center gap-2">
                            <FileText size={40} className="text-green-500" />
                            <p className="font-bold text-gray-900 dark:text-white">{verificationFile.name}</p>
                            <p className="text-xs text-green-500 font-bold">File Selected</p>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-2">
                            <Upload size={40} className="text-gray-400" />
                            <p className="font-bold text-gray-900 dark:text-white">Upload ID Card</p>
                            <p className="text-xs text-gray-500">PNG, JPG or PDF (Max 5MB)</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </Section>

                  <button 
                    onClick={submitVerification}
                    disabled={!verificationFile || isVerifying}
                    className="w-full bg-[#1A2933] text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {isVerifying ? 'Submitting Request...' : 'Submit Request'}
                  </button>
                </>
              )}
            </div>
          )}

          {/* 2. Privacy Controls */}
          {activeTab === 'privacy' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h2 className="text-3xl font-black mb-2 text-gray-900 dark:text-white">Privacy Controls</h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium mb-8">Determine who can see and interact with your content.</p>

              <Section title="Profile Visibility">
                <Row icon={<EyeOff size={20}/>} title="Private Account" description="Only approved followers can see your posts and reels." action={<Toggle checked={toggles['private_account']} onChange={() => handleToggle('private_account')} />} border={false} />
              </Section>

              <Section title="Interactions">
                <Row icon={<MessageSquare size={20}/>} title="Comments" description="Control who can comment on your posts" action={
                  <select className="bg-gray-100 dark:bg-gray-700 border-none rounded-lg px-3 py-1.5 font-bold text-gray-700 dark:text-white outline-none cursor-pointer">
                    <option>Everyone</option>
                    <option>Friends Only</option>
                    <option>No One</option>
                  </select>
                } />
                <Row icon={<User size={20}/>} title="Tags & Mentions" description="Choose who can tag you" action={
                  <select className="bg-gray-100 dark:bg-gray-700 border-none rounded-lg px-3 py-1.5 font-bold text-gray-700 dark:text-white outline-none cursor-pointer">
                    <option>Everyone</option>
                    <option>Friends Only</option>
                  </select>
                } />
                <Row icon={<Shield size={20}/>} title="Active Status" description="Show when you are online" action={<Toggle checked={toggles['active_status']} onChange={() => handleToggle('active_status')} />} border={false} />
              </Section>
            </div>
          )}

          {/* 4. Content & Display */}
          {activeTab === 'display' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h2 className="text-3xl font-black mb-2 text-gray-900 dark:text-white">Content & Display</h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium mb-8">Customize how the app looks and what you see.</p>

              <Section title="Appearance">
                <div className="p-4 border-b border-gray-100 dark:border-gray-700">
                  <p className="font-bold text-gray-900 dark:text-white mb-3">Display Mode</p>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => !darkMode && toggleDarkMode()}
                      className={`flex flex-col items-center gap-2 p-3 border-2 rounded-xl font-bold transition-colors ${!darkMode ? 'border-[#1A2933] bg-blue-50 text-[#1A2933]' : 'border-transparent bg-gray-100 text-gray-700'}`}
                    >
                      <Sun size={24} /> Light
                    </button>
                    <button 
                      onClick={() => darkMode && toggleDarkMode()}
                      className={`flex flex-col items-center gap-2 p-3 border-2 rounded-xl font-bold transition-colors ${darkMode ? 'border-[#1A2933] bg-gray-800 text-white' : 'border-transparent bg-gray-100 text-gray-700'}`}
                    >
                      <Moon size={24} /> Dark
                    </button>
                  </div>
                </div>
                <Row icon={<Type size={20}/>} title="Font Size" description="Adjust text size for better readability" action={
                  <input type="range" min="1" max="3" defaultValue="2" className="w-32 accent-[#1A2933]" />
                } border={false} />
              </Section>
            </div>
          )}

           {/* 3. Notifications */}
           {activeTab === 'notifications' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h2 className="text-3xl font-black mb-2 text-gray-900 dark:text-white">Notifications</h2>
              <Section title="Push Notifications">
                <Row title="Likes & Reactions" description="When someone likes your post" action={<Toggle checked={toggles['push_likes']} onChange={() => handleToggle('push_likes')} />} />
                <Row title="Comments" description="When someone comments on your post" action={<Toggle checked={toggles['push_comments']} onChange={() => handleToggle('push_comments')} />} />
              </Section>
            </div>
          )}



           {/* 7. Help & Support */}
           {activeTab === 'help' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <h2 className="text-3xl font-black mb-2 text-gray-900 dark:text-white">Help & Support</h2>
              <Section title="Support">
                <Row icon={<AlertTriangle size={20}/>} title="Report a Problem" description="Send feedback or report a bug" action={<button className="bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-white px-4 py-1.5 rounded-lg font-bold transition-colors">Report</button>} />
              </Section>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default Settings;
