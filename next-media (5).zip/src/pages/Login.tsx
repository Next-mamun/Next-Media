
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/App';
import { supabase } from '../lib/supabase';
import { User, Lock, Key } from 'lucide-react';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [showPinField, setShowPinField] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { setCurrentUser } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!username || !password) {
      setError('Please enter all fields');
      setLoading(false);
      return;
    }

    const { data, error: fetchError } = await supabase
      .from('profiles')
      .select('*')
      .eq('username', username.toLowerCase())
      .single();

    if (fetchError || !data) {
      setError('User not found');
      setLoading(false);
      return;
    }

    // Check Password and optionally PIN
    if (data.password === password) {
      if (data.backup_pin && pin && data.backup_pin !== pin) {
        setError('Invalid Backup PIN');
        setLoading(false);
        return;
      }
      setCurrentUser(data);
      navigate('/');
    } else {
      setError('Invalid password');
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col lg:flex-row items-center justify-center min-h-[90vh] gap-12 lg:gap-32 p-4 bg-[#f0f2f5]">
      <div className="max-w-[500px] text-center lg:text-left">
        <h1 className="text-[#1877F2] text-6xl font-extrabold tracking-tighter mb-4">next media</h1>
        <p className="text-2xl font-medium text-gray-800 leading-tight">
          Connect with friends and the world around you on Next Media.
        </p>
      </div>

      <div className="w-full max-w-[400px] bg-white p-6 rounded-xl shadow-2xl border border-gray-100">
        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <div className="relative">
            <User size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-4 pl-12 border rounded-lg focus:ring-2 focus:ring-blue-100 outline-none text-lg bg-gray-50 text-gray-900 placeholder-gray-400"
            />
          </div>
          
          <div className="relative">
            <Lock size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-4 pl-12 border rounded-lg focus:ring-2 focus:ring-blue-100 outline-none text-lg bg-gray-50 text-gray-900 placeholder-gray-400"
            />
          </div>
          
          {showPinField && (
            <div className="relative animate-in fade-in slide-in-from-top-1">
              <Key size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Backup PIN (Optional)"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                maxLength={4}
                className="w-full p-4 pl-12 border rounded-lg focus:ring-2 focus:ring-blue-100 outline-none text-lg bg-gray-50 text-gray-900 placeholder-gray-400"
              />
            </div>
          )}

          {error && <p className="text-red-500 text-sm text-center font-medium bg-red-50 p-2 rounded border border-red-100">{error}</p>}

          <button 
            type="submit"
            disabled={loading}
            className="bg-[#1877F2] text-white py-3.5 rounded-lg text-xl font-bold hover:bg-[#166fe5] shadow-lg transition-all disabled:opacity-50 active:scale-[0.98]"
          >
            {loading ? 'Authenticating...' : 'Log In'}
          </button>
          
          <button 
            type="button"
            onClick={() => setShowPinField(!showPinField)}
            className="text-[#1877F2] text-sm hover:underline font-semibold"
          >
            {showPinField ? 'Hide Backup PIN' : 'Use Backup PIN?'}
          </button>

          <div className="h-px bg-gray-200 my-2" />

          <Link 
            to="/register"
            className="bg-[#42b72a] text-white py-3.5 rounded-lg text-lg font-bold hover:bg-[#36a420] transition-all text-center shadow-md active:scale-[0.98]"
          >
            Create new account
          </Link>
        </form>
      </div>
    </div>
  );
};

export default Login;
