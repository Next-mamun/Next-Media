
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Lock, Shield, UserCircle, Key } from 'lucide-react';
import { useAuth } from '@/App';
import { generateBio } from '../services/geminiService';
import { supabase } from '../lib/supabase';

const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    username: '',
    password: '',
    pin: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { setCurrentUser } = useAuth();
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!formData.firstName || !formData.lastName || !formData.username || !formData.password) {
      setError('Required fields are missing');
      setLoading(false);
      return;
    }

    const usernameLower = formData.username.toLowerCase();

    // Check for existing user
    const { data: existing } = await supabase.from('profiles').select('id').eq('username', usernameLower).single();
    if (existing) {
      setError('Username already taken');
      setLoading(false);
      return;
    }

    try {
      const bio = await generateBio(usernameLower);
      const { data, error: insertError } = await supabase.from('profiles').insert([
        {
          username: usernameLower,
          password: formData.password,
          backup_pin: formData.pin || null,
          display_name: `${formData.firstName} ${formData.lastName}`,
          bio: bio,
          avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${usernameLower}`
        }
      ]).select().single();

      if (insertError) throw insertError;
      
      setCurrentUser(data);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[90vh] p-4 bg-[#f0f2f5]">
      <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-2xl w-full max-w-[440px] border border-gray-100">
        <div className="mb-6">
          <h1 className="text-4xl font-black tracking-tight text-gray-900">Sign Up</h1>
          <p className="text-gray-500 font-medium">It's quick and easy.</p>
        </div>
        
        <div className="h-px bg-gray-100 mb-6" />

        <form onSubmit={handleRegister} className="flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                placeholder="First name"
                className="w-full p-3 pl-10 bg-gray-50 border rounded-xl outline-none focus:ring-2 focus:ring-blue-100 text-gray-900 placeholder-gray-400 font-medium"
                onChange={e => setFormData({...formData, firstName: e.target.value})}
              />
            </div>
            <div className="relative flex-1">
              <input
                placeholder="Last name"
                className="w-full p-3 bg-gray-50 border rounded-xl outline-none focus:ring-2 focus:ring-blue-100 text-gray-900 placeholder-gray-400 font-medium"
                onChange={e => setFormData({...formData, lastName: e.target.value})}
              />
            </div>
          </div>
          
          <div className="relative">
            <UserCircle size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              placeholder="Username (unique identifier)"
              className="w-full p-3 pl-10 bg-gray-50 border rounded-xl outline-none focus:ring-2 focus:ring-blue-100 text-gray-900 placeholder-gray-400 font-medium"
              onChange={e => setFormData({...formData, username: e.target.value})}
            />
          </div>
          
          <div className="relative">
            <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="password"
              placeholder="New password"
              className="w-full p-3 pl-10 bg-gray-50 border rounded-xl outline-none focus:ring-2 focus:ring-blue-100 text-gray-900 placeholder-gray-400 font-medium"
              onChange={e => setFormData({...formData, password: e.target.value})}
            />
          </div>

          <div className="relative">
            <Key size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Backup PIN (4 digits)"
              maxLength={4}
              className="w-full p-3 pl-10 bg-gray-50 border rounded-xl outline-none focus:ring-2 focus:ring-blue-100 text-gray-900 placeholder-gray-400 font-medium"
              onChange={e => setFormData({...formData, pin: e.target.value})}
            />
          </div>

          {error && <p className="text-red-500 text-sm text-center font-bold bg-red-50 p-2 rounded">{error}</p>}

          <p className="text-[11px] text-gray-500 text-center px-4">
            By clicking Sign Up, you agree to our <span className="text-blue-600 cursor-pointer hover:underline">Terms</span>, <span className="text-blue-600 cursor-pointer hover:underline">Privacy Policy</span> and <span className="text-blue-600 cursor-pointer hover:underline">Cookies Policy</span>.
          </p>

          <button 
            type="submit"
            disabled={loading}
            className="bg-[#00a400] text-white py-3.5 rounded-xl font-bold text-xl mt-2 hover:bg-[#008f00] shadow-lg disabled:opacity-50 transition-all active:scale-[0.98]"
          >
            {loading ? 'Creating Account...' : 'Sign Up'}
          </button>

          <Link to="/login" className="text-[#1877F2] text-center mt-3 text-sm hover:underline font-bold">
            Already have an account?
          </Link>
        </form>
      </div>
    </div>
  );
};

export default Register;
